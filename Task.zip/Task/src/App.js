import React, { Component } from "react";
import { connect } from "react-redux";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
  Link
} from "react-router-dom";
import { Form, Icon, Input, Button, Checkbox } from 'antd';
import './App.css';
import WrappedNormalLoginForm from './Login';
import Wrappedslider from './Slider';

function App() {
  return (
    <div>
      <Router>
        <div>
          <Switch>
            <Route path="/login">
              <WrappedNormalLoginForm />
            </Route>
            <Route path="/slider">
              <Wrappedslider />
            </Route>
          </Switch>
        </div>
      </Router>
    </div>
  );
}

export default App;
