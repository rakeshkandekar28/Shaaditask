import React, { Component } from "react";
import Slider from "react-slick";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
  Link
} from "react-router-dom";
import { Form, Icon, Input, Checkbox, Select, Modal, Button } from 'antd';
import './App.css';

const { Option } = Select;
class Slidercom extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Selectedvalue: [],
      slidercount: [],
      allselectesvaluebyUser: [],
      visible: false
    }
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {

  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = e => {
    console.log(e);
    this.setState({
      visible: false,
    });
  };

  handleCancel = e => {
    console.log(e);
    this.setState({
      visible: false,
    });
  };


  handleChange(value) {
    this.setState({
      Selectedvalue: value
    });

    var newStateArray = this.state.allselectesvaluebyUser;
    const updatedArray = this.state.allselectesvaluebyUser.concat({
      selectid: value
    })

    this.setState({
      allselectesvaluebyUser: updatedArray
    })
  }


  getSliderImage() {

    const ArrList = [];

    for (var i = 0; i < this.state.Selectedvalue; i++) {
      ArrList.push({
        id: i
      });
    }


    var settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1
    };



    const sliderelement = ArrList.map(slidervalue => (

      <div className="sliderbanner" key={slidervalue.id}>
        <div className="slidertext">{slidervalue.id}</div>
      </div>


    ))


    return (
      <div>
        <Slider {...settings}>
          {sliderelement}
        </Slider>

      </div>
    )
  }


  render() {
    const { getFieldDecorator } = this.props.form;
    const selectcount = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];




    return (
      <div>

        <div className="text-center">
          <Select
            style={{ width: 120 }}
            onChange={this.handleChange}
            defaultValue="Select Number"
          >
            {selectcount.map(value => {
              return <Option key={value}>{value}</Option>
            })}
          </Select>

          <Button type="primary" onClick={this.showModal}>
            Finish
        </Button>
        </div>

        <Modal
          title="User Selected Value"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >

          {this.state.allselectesvaluebyUser.map(value => {
            return <div key={value.selectid}>{value.selectid}</div>
          })}

        </Modal>



        <div> {this.getSliderImage()}</div>


      </div>
    );
  }
}


const Wrappedslider = Form.create()(Slidercom);

export default Wrappedslider;

