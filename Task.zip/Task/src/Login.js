import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
  Link
} from "react-router-dom";
import { Form, Icon, Input, Button, Checkbox } from 'antd';
import './App.css';


class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: 'shaadi',
      password: '123',
      redirectsliderpage: false,
      ifwrongcredential: false
    }
  }

  componentDidMount() {

  }


  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values.username);
        if (values.username === this.state.username && values.password === this.state.password) {
          this.setState({
            redirectsliderpage: true
          })
          console.log('Login Success');
        } else {
          this.setState({
            ifwrongcredential: true
          })
          console.log('Login Fail');
        }
      }
    });
  };


  render() {
    const { getFieldDecorator } = this.props.form;
    if (this.state.redirectsliderpage === true) {
      return <Redirect to="/slider" />;
      //this.props.history.push('/hotelList');
    }
    return (
      <div>
        <Form onSubmit={this.handleSubmit} className="login-form">
          <Form.Item>
            {getFieldDecorator('username', {
              rules: [{ required: true, message: 'Please input your username!' }],
            })(
              <Input
                prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                placeholder="Username"
              />,
            )}
          </Form.Item>
          <Form.Item>
            {getFieldDecorator('password', {
              rules: [{ required: true, message: 'Please input your Password!' }],
            })(
              <Input
                prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                type="password"
                placeholder="Password"
              />,
            )}
          </Form.Item>
          <Form.Item>

            <Button type="primary" htmlType="submit" className="login-form-button">
              Log in
          </Button>

          </Form.Item>
        </Form>

        {this.state.ifwrongcredential ?
          <div className="text-danger text-center">You are Using wrong Credentials!!!</div>
          :
          <div></div>
        }
      </div>
    );
  }
}


const WrappedNormalLoginForm = Form.create()(Login);

export default WrappedNormalLoginForm;

